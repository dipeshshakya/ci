
<?php $this->load->view('header');?>
<?php $this->load->view('navbar2');?>

<?php $this->load->view('tabs2',$data);?>
<?php $this->load->view('footer');?>