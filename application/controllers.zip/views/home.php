<?php $this->load->view('header');?>
<?php $this->load->view('navbar1');?>

<?php $this->load->view('map',$info);?>

<?php $this->load->view('footer');?>